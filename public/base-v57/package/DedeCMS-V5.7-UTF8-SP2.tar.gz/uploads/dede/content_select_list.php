<?php
/**
 * 选择文章
 *
 * @version        $Id: content_select_list.php 1 14:31 2010年7月12日 $
 * @package        DedeCMS.Administrator
 * @founder        IT柏拉图, https://weibo.com/itprato
 * @author         DedeCMS团队
 * @copyright      Copyright (c) 2007 - 2021, 上海卓卓网络科技有限公司 (DesDev, Inc.)
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
$s_tmplets = "templets/content_select_list.htm";
include(dirname(__FILE__)."/content_list.php");
